var firebaseConfig = {
	apiKey: "AIzaSyBc3LePvCDUHgqi72DEJMP-68wuqhvMsOk",
	authDomain: "memowebapp-4e9f3.firebaseapp.com",
	projectId: "memowebapp-4e9f3",
	storageBucket: "memowebapp-4e9f3.appspot.com",
	messagingSenderId: "1008131090658",
	appId: "1:1008131090658:web:723146b4de1d223d0196bb",
	measurementId: "G-1KRZYRCMRH"
};

firebase.initializeApp(firebaseConfig);