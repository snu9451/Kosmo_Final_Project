//제공 함수를 통한 패턴 분석1
{
  //console.log('test');
  let addNum = 0;
  const auto = setTimeout(function () {
    addNum++;
    console.log(addNum);
  }, 3000);
}