!(function ($) {
  ("use strict");

})(jQuery);
