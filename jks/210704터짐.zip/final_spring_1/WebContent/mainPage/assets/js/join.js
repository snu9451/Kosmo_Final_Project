
!(function($) {
	("use strict");

})(jQuery);
